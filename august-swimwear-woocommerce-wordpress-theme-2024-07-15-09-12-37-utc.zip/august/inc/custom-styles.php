<?php
if ( !function_exists ('august_custom_styles') ) {
	function august_custom_styles() {
		global $post;	
		
		ob_start();	
		?>
		
			<?php if ( august_get_config('main_color') != "" ) {
				$main_color = august_get_config('main_color');
			} else {
				$main_color = '#B96F4A';
			}


			if ( august_get_config('main_hover_color') != "" ) {
				$main_hover_color = august_get_config('main_hover_color');
			} else {
				$main_hover_color = '#df8140';
			}

			if ( august_get_config('text_color') != "" ) {
				$text_color = august_get_config('text_color');
			} else {
				$text_color = '#616174';
			}

			if ( august_get_config('link_color') != "" ) {
				$link_color = august_get_config('link_color');
			} else {
				$link_color = '#152242';
			}

			if ( august_get_config('heading_color') != "" ) {
				$heading_color = august_get_config('heading_color');
			} else {
				$heading_color = '#152242';
			}
			

			$main_color_rgb = august_hex2rgb($main_color);

			// font
			$main_font = august_get_config('main_font');
			$main_font_family = !empty($main_font['font-family']) ? $main_font['font-family'] : 'Futura';
			$main_font_weight = !empty($main_font['font-weight']) ? $main_font['font-weight'] : 400;

			$main_font_arr = explode(',', $main_font_family);
			if ( count($main_font_arr) == 1 ) {
				$main_font_family = "'".$main_font_family."'";
			}

			$heading_font = august_get_config('heading_font');
			$heading_font_family = !empty($heading_font['font-family']) ? $heading_font['font-family'] : 'Butler';
			$heading_font_weight = !empty($heading_font['font-weight']) ? $heading_font['font-weight'] : 500;

			$heading_font_arr = explode(',', $heading_font_family);
			if ( count($heading_font_arr) == 1 ) {
				$heading_font_family = "'".$heading_font_family."'";
			}
			?>
			:root {
			  --august-theme-color: <?php echo trim($main_color); ?>;
			  --august-text-color: <?php echo trim($text_color); ?>;
			  --august-link-color: <?php echo trim($link_color); ?>;
			  --august-heading-color: <?php echo trim($heading_color); ?>;
			  --august-theme-hover-color: <?php echo trim($main_hover_color); ?>;
			  --august-theme-color-001: <?php echo august_generate_rgba($main_color_rgb, 0.01); ?>
			  --august-theme-color-01: <?php echo august_generate_rgba($main_color_rgb, 0.1); ?>

			  --august-main-font: <?php echo trim($main_font_family); ?>;
			  --august-main-font-weight: <?php echo trim($main_font_weight); ?>;
			  --august-heading-font: <?php echo trim($heading_font_family); ?>;
			  --august-heading-font-weight: <?php echo trim($heading_font_weight); ?>;
			}
			
			<?php if (  august_get_config('header_mobile_color') != "" ) : ?>
				#apus-header-mobile {
					background-color: <?php echo esc_html( august_get_config('header_mobile_color') ); ?>;
				}
			<?php endif; ?>

	<?php
		$content = ob_get_clean();
		$content = str_replace(array("\r\n", "\r"), "\n", $content);
		$lines = explode("\n", $content);
		$new_lines = array();
		foreach ($lines as $i => $line) {
			if (!empty($line)) {
				$new_lines[] = trim($line);
			}
		}
		
		return implode($new_lines);
	}
}