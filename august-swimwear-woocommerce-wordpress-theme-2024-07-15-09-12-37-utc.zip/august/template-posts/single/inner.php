<?php
$post_format = get_post_format();
global $post;
$thumb = august_post_thumbnail();
?>
<article id="post-<?php the_ID(); ?>" <?php post_class('main-detail-post'); ?>>
    <div class="post-layout">
        <div class="date">
            <a href="<?php the_permalink(); ?>" class="text-theme"><?php the_time( get_option('date_format', 'd M, Y') ); ?></a>
        </div>
        <?php if (get_the_title()) { ?>
            <h1 class="entry-title-detail">
                <?php the_title(); ?>
            </h1>
        <?php } ?>
        <?php if($thumb) {?>
            <div class="entry-thumb-detail top-image">
                <?php
                    echo trim($thumb);
                ?>
            </div>
        <?php } ?>
    </div>
	<div class="entry-content-detail">
        <div class="wrapper-small">
        	<div class="single-info">
                <div class="entry-description clearfix">
                    <?php
                        the_content();
                    ?>
                </div><!-- /entry-content -->
        		<?php
                wp_link_pages( array(
                    'before'      => '<div class="page-links"><span class="page-links-title">' . esc_html__( 'Pages:', 'august' ) . '</span>',
                    'after'       => '</div>',
                    'link_before' => '<span>',
                    'link_after'  => '</span>',
                    'pagelink'    => '<span class="screen-reader-text">' . esc_html__( 'Page', 'august' ) . ' </span>%',
                    'separator'   => '',
                ) );
                ?>
                <?php  
                    $posttags = get_the_tags();
                ?>
                <?php if( !empty($posttags) || august_get_config('show_blog_social_share', false) ){ ?>
            		<div class="tag-social clearfix flex-middle-md flex-middle-lg">
                        <?php august_post_tags(); ?>
                        <div class="ali-right">
                			<?php if( august_get_config('show_blog_social_share', false) ) {
                				get_template_part( 'template-parts/sharebox' );
                			} ?>
                        </div>
            		</div>
                <?php } ?>

                <?php 
                //Previous/next post navigation.
                the_post_navigation( array(
                    'next_text' => 
                        '<div class="inner">'.
                        '<div class="navi">'. esc_html__( 'Next Post', 'august' ) . '<i class="flaticon-chevron"></i></div>'.
                        '<span class="title-direct">%title</span></div>',
                    'prev_text' => 
                        '<div class="inner">'.
                        '<div class="navi"><i class="flaticon-left-arrow"></i>' . esc_html__( 'Previous Post', 'august' ) . '</div>'.
                        '<span class="title-direct">%title</span></div>',
                ) );
                ?>
        	</div>
        </div>
    </div>
</article>