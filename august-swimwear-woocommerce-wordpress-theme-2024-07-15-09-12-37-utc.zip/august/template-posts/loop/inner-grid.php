<?php 
    $thumbsize = !isset($thumbsize) ? august_get_config( 'blog_item_thumbsize', 'full' ) : $thumbsize;
    $thumb = august_display_post_thumb($thumbsize);
?>
<article <?php post_class('post post-layout post-grid'); ?>>
    <?php if($thumb) {?>
        <div class="top-image">
            <?php
                echo trim($thumb);
            ?>
        </div>
    <?php } ?>
    <div class="inner">
        <div class="date">
            <a href="<?php the_permalink(); ?>" class="text-theme"><?php the_time( get_option('date_format', 'd M, Y') ); ?></a>
        </div>
        <?php if (get_the_title()) { ?>
            <h4 class="entry-title">
                <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
            </h4>
        <?php } ?>
        <?php if( !empty( get_the_excerpt() ) ){?>
            <div class="description"><?php echo august_substring( get_the_excerpt(), 19, '' ); ?></div>
        <?php } ?>
        <div class="readmore">
            <a class="btn btn-theme" href="<?php the_permalink(); ?>"><?php esc_html_e('Read More', 'august'); ?></a>
        </div>
    </div>
</article>