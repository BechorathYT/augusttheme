<?php
	$columns = august_get_config('blog_columns', 1);
	$bcol = floor( 12 / $columns );

	$inner_item = !isset($args['inner_item']) ? 'list' : $args['inner_item'];
?>
<div class="layout-posts-list">
    <?php while ( have_posts() ) : the_post(); ?>
        <?php get_template_part( 'template-posts/loop/inner', $inner_item ); ?>
    <?php endwhile; ?>
</div>