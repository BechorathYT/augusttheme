<div class="apus-search-form">
	<div class="apus-search-form-inner">
		<form action="<?php echo esc_url( home_url( '/' ) ); ?>" method="get">
			<div class="main-search">
				<div class="autocompleate-wrapper">
			  		<input type="text" placeholder="<?php esc_attr_e( 'Search Product...', 'august' ); ?>" name="s" class="apus-search form-control apus-autocompleate-input" autocomplete="off"/>
				</div>
			</div>
			<input type="hidden" name="post_type" value="product" class="post_type" />
			
			<button type="submit" class="btn-search btn btn-theme"><i class="flaticon-search"></i></button>
		</form>
	</div>
</div>