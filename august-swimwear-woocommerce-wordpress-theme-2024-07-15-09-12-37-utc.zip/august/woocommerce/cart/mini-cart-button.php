<?php global $woocommerce; ?>
<div class="apus-topcart">
 	<div class="cart">
        <a class="dropdown-toggle mini-cart" data-toggle="dropdown" aria-expanded="true" role="button" aria-haspopup="true" data-delay="0" href="#" title="<?php esc_attr_e('View your shopping cart', 'august'); ?>">
            <svg class="svg-cart" width="24" height="24" viewBox="0 0 15 15" xmlns="//www.w3.org/2000/svg" aria-hidden="true">
                <path d="M12.373 13.442H2.325l-.91-8.672h11.812l-.854 8.672zM5.63 1.724c.422-.44.977-.655 1.7-.655 1.873 0 2.458 1.622 2.64 2.649H4.81c.078-.607.28-1.427.82-1.994zm8.567 2.167a.524.524 0 0 0-.39-.173h-2.79C10.78 2.13 9.833.042 7.329.042c-1.006 0-1.83.329-2.446.978-.769.808-1.027 1.933-1.11 2.698H.83a.53.53 0 0 0-.392.174.519.519 0 0 0-.13.406l1.018 9.725c.028.268.254.47.523.47h11c.27 0 .498-.204.523-.473l.958-9.725a.525.525 0 0 0-.134-.404z" fill-rule="evenodd"></path>
            </svg>
            <span class="count"><?php echo sprintf($woocommerce->cart->cart_contents_count); ?></span>
        </a>
        <div class="dropdown-menu dropdown-menu-right"><div class="widget_shopping_cart_content">
            <?php woocommerce_mini_cart(); ?>
        </div></div>
    </div>
</div>