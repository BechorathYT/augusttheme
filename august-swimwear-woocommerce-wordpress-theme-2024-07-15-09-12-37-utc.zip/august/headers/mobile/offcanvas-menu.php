<div id="apus-mobile-menu" class="apus-offcanvas hidden-lg"> 
    <div class="apus-offcanvas-body">
        <?php if ( defined('AUGUST_WOOCOMMERCE_ACTIVED') && august_get_config('show_searchform', true) ) { ?>
            <div class="header-offcanvas">
                <?php
                    get_template_part('template-parts/productsearchform-nocategory');
                ?>
            </div>
        <?php } ?>
        <div class="middle-offcanvas">
            <nav id="menu-main-menu-navbar" class="navbar navbar-offcanvas" role="navigation">
                <?php
                    $mobile_menu = 'primary';
                    $menus = get_nav_menu_locations();
                    if( !empty($menus['mobile-primary']) && wp_get_nav_menu_items($menus['mobile-primary'])) {
                        $mobile_menu = 'mobile-primary';
                    }
                    $args = array(
                        'theme_location' => $mobile_menu,
                        'container_class' => '',
                        'menu_class' => '',
                        'fallback_cb' => '',
                        'menu_id' => '',
                        'container' => 'div',
                        'container_id' => 'mobile-menu-container',
                        'walker' => new August_Mobile_Menu()
                    );
                    wp_nav_menu($args);

                ?>

                <?php if ( august_get_config('show_login_register', true) ) { ?>
                    <a class="my-account" href="<?php echo esc_url( get_permalink( get_option('woocommerce_myaccount_page_id') ) ); ?>">
                        <?php if ( is_user_logged_in() ) { ?>
                            <?php esc_html_e('MY ACCOUNT', 'august'); ?>
                        <?php }else{ ?>
                            <?php esc_html_e('LOGIN & REGISTER', 'august'); ?>
                        <?php } ?>
                    </a>
                <?php } ?>

            </nav>
        </div>
        <?php if ( is_active_sidebar( 'header-mobile-bottom' ) ) { ?>
            <div class="header-mobile-bottom">
                <?php if ( is_active_sidebar( 'header-mobile-bottom' ) ){ ?>
                    <?php dynamic_sidebar( 'header-mobile-bottom' ); ?>
                <?php } ?>
            </div>
        <?php } ?>

    </div>
</div>
<div class="over-dark"></div>