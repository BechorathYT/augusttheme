<header id="apus-header" class="apus-header header-default visible-lg" role="banner">
    <div class="<?php echo (august_get_config('keep_header') ? 'main-sticky-header-wrapper' : ''); ?>">
        <div class="<?php echo (august_get_config('keep_header') ? 'main-sticky-header' : ''); ?>">
            <div class="container">
                <div class="row flex-middle">
                    <div class="col-md-2">
                        <div class="logo-in-theme">
                            <?php get_template_part( 'template-parts/logo/logo' ); ?>
                        </div>
                    </div>
                    <div class="col-md-10 flex-middle">
                        <?php if ( has_nav_menu( 'primary' ) ) : ?>
                            <div class="main-menu">
                                <nav data-duration="400" class="apus-megamenu slide animate navbar p-static" role="navigation">
                                <?php
                                    $args = array(
                                        'theme_location' => 'primary',
                                        'container_class' => 'collapse navbar-collapse no-padding',
                                        'menu_class' => 'nav navbar-nav megamenu effect1',
                                        'fallback_cb' => '',
                                        'menu_id' => 'primary-menu',
                                        'walker' => new August_Nav_Menu()
                                    );
                                    wp_nav_menu($args);
                                ?>
                                </nav>
                            </div>
                        <?php endif; ?>
                        <div class="header-right clearfix">
                            <?php if ( defined('AUGUST_WOOCOMMERCE_ACTIVED') && august_get_config('show_cartbtn') && !august_get_config( 'enable_shop_catalog' ) ): ?>

                                <div class="pull-right">
                                    <div class="apus-topcart">
                                        <div class="cart">
                                            <a class="dropdown-toggle mini-cart" data-toggle="dropdown" aria-expanded="true" href="#" title="<?php esc_attr_e('View your shopping cart', 'august'); ?>">
                                                <svg class="svg-cart" width="24" height="24" viewBox="0 0 15 15" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
                                                    <path d="M12.373 13.442H2.325l-.91-8.672h11.812l-.854 8.672zM5.63 1.724c.422-.44.977-.655 1.7-.655 1.873 0 2.458 1.622 2.64 2.649H4.81c.078-.607.28-1.427.82-1.994zm8.567 2.167a.524.524 0 0 0-.39-.173h-2.79C10.78 2.13 9.833.042 7.329.042c-1.006 0-1.83.329-2.446.978-.769.808-1.027 1.933-1.11 2.698H.83a.53.53 0 0 0-.392.174.519.519 0 0 0-.13.406l1.018 9.725c.028.268.254.47.523.47h11c.27 0 .498-.204.523-.473l.958-9.725a.525.525 0 0 0-.134-.404z" fill-rule="evenodd"></path>
                                                </svg>
                                                <span class="count"><?php echo WC()->cart->get_cart_contents_count(); ?></span>
                                            </a>
                                            <div class="dropdown-menu dropdown-menu-right">
                                                <div class="widget_shopping_cart_content">
                                                    <?php woocommerce_mini_cart(); ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            <?php endif; ?>

                            <?php if ( class_exists( 'YITH_WCWL' ) && august_get_config('show_wishlist_btn', true) ):
                                $wishlist_url = YITH_WCWL()->get_wishlist_url();
                            ?>
                                <div class="pull-right">
                                    <a class="wishlist-icon" href="<?php echo esc_url($wishlist_url);?>">
                                        <svg aria-hidden="true" width="24" height="24" focusable="false" data-prefix="fal" data-icon="heart" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" class="svg-heart"><path fill="currentColor" d="M462.3 62.7c-54.5-46.4-136-38.7-186.6 13.5L256 96.6l-19.7-20.3C195.5 34.1 113.2 8.7 49.7 62.7c-62.8 53.6-66.1 149.8-9.9 207.8l193.5 199.8c6.2 6.4 14.4 9.7 22.6 9.7 8.2 0 16.4-3.2 22.6-9.7L472 270.5c56.4-58 53.1-154.2-9.7-207.8zm-13.1 185.6L256.4 448.1 62.8 248.3c-38.4-39.6-46.4-115.1 7.7-161.2 54.8-46.8 119.2-12.9 142.8 11.5l42.7 44.1 42.7-44.1c23.2-24 88.2-58 142.8-11.5 54 46 46.1 121.5 7.7 161.2z" class=""></path></svg>
                                        <?php if ( function_exists('yith_wcwl_count_products') ) { ?>
                                            <span class="count"><?php echo yith_wcwl_count_products(); ?></span>
                                        <?php } ?>
                                    </a>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</header>