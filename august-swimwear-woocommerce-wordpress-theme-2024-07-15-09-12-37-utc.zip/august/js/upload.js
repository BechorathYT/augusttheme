jQuery(document).ready(function($){
	"use strict";
	var august_upload;
	var august_selector;

	function august_add_file(event, selector) {

		var upload = $(".uploaded-file"), frame;
		var $el = $(this);
		august_selector = selector;

		event.preventDefault();

		// If the media frame already exists, reopen it.
		if ( august_upload ) {
			august_upload.open();
			return;
		} else {
			// Create the media frame.
			august_upload = wp.media.frames.august_upload =  wp.media({
				// Set the title of the modal.
				title: "Select Image",

				// Customize the submit button.
				button: {
					// Set the text of the button.
					text: "Selected",
					// Tell the button not to close the modal, since we're
					// going to refresh the page when the image is selected.
					close: false
				}
			});

			// When an image is selected, run a callback.
			august_upload.on( 'select', function() {
				// Grab the selected attachment.
				var attachment = august_upload.state().get('selection').first();

				august_upload.close();
				august_selector.find('.upload_image').val(attachment.attributes.url).change();
				if ( attachment.attributes.type == 'image' ) {
					august_selector.find('.august_screenshot').empty().hide().prepend('<img src="' + attachment.attributes.url + '">').slideDown('fast');
				}
			});

		}
		// Finally, open the modal.
		august_upload.open();
	}

	function august_remove_file(selector) {
		selector.find('.august_screenshot').slideUp('fast').next().val('').trigger('change');
	}
	
	$('body').on('click', '.august_upload_image_action .remove-image', function(event) {
		august_remove_file( $(this).parent().parent() );
	});

	$('body').on('click', '.august_upload_image_action .add-image', function(event) {
		august_add_file(event, $(this).parent().parent());
	});

});